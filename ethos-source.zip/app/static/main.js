'use strict';
(() => {
  let toastTimer;
  function flash(message) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
  }
  async function copyText(value) {
    try {
      await navigator.clipboard.writeText(value);
    } catch (_) {
      // Browsers without Clipboard API can use a short-lived selection fallback.
      const temp = document.createElement('textarea');
      temp.value = value;
      temp.style.cssText = 'position:fixed;left:-9999px;top:-9999px';
      document.body.appendChild(temp);
      temp.select();
      const copied = document.execCommand('copy');
      temp.remove();
      if (!copied) { flash('Selecione e copie o texto manualmente.'); return; }
    }
    flash('Copiado!');
  }
  document.addEventListener('click', (event) => {
    const control = event.target.closest('[data-copy-target],[data-copy-text]');
    if (!control) return;
    const text = control.dataset.copyText || document.getElementById(control.dataset.copyTarget)?.value || '';
    if (text) copyText(text);
  });
  document.querySelectorAll('form[data-confirm]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      if (!window.confirm(form.dataset.confirm)) event.preventDefault();
    });
  });
})();
