"""Environment-driven configuration; production secrets are never hard-coded."""
from dataclasses import dataclass
import os
import secrets
from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    environment: str
    database_url: str
    secret_key: str
    secure_cookies: bool
    base_url: str


def read_settings() -> Settings:
    environment = os.getenv("APP_ENV", "development").strip().lower()
    secret_key = os.getenv("SECRET_KEY", "")
    if environment == "production" and len(secret_key) < 32:
        raise RuntimeError("SECRET_KEY deve ter ao menos 32 caracteres em produção.")
    database_url = os.getenv("DATABASE_URL", "sqlite:///./data/ethos.db")
    if database_url.startswith(("postgres://", "postgresql://")):
        database_url = "postgresql+psycopg://" + database_url.split("://", 1)[1]
    if environment == "production" and not database_url.startswith("postgresql+psycopg://"):
        raise RuntimeError("Produção exige PostgreSQL persistente.")
    if environment == "production" and "sslmode=require" not in database_url and "sslmode=verify-full" not in database_url:
        raise RuntimeError("Produção exige TLS na conexão PostgreSQL.")
    return Settings(
        environment=environment,
        database_url=database_url,
        secret_key=secret_key or secrets.token_urlsafe(48),
        secure_cookies=os.getenv("SECURE_COOKIES", "false").lower() == "true" or environment == "production",
        base_url=os.getenv("BASE_URL", "http://localhost:8000").rstrip("/"),
    )
