"""Event capacity, waitlist promotion, formatting and admin exports."""
import re
import secrets
import unicodedata
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from .models import Event, Registration, utc_now
from .security import hash_token


def slugify(value: str) -> str:
    simple = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", simple).strip("-")[:100]


def clean_phone(phone: str) -> str:
    digits = re.sub(r"\D", "", phone)
    if digits.startswith("55") and len(digits) in (12, 13):
        digits = digits[2:]
    if len(digits) not in (10, 11) or digits[0] == "0":
        raise ValueError("Informe um WhatsApp com DDD (10 ou 11 números).")
    return "55" + digits


def money(cents: int) -> str:
    return "R$ " + f"{cents / 100:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def occupancy(db: Session, event_id: int) -> tuple[int, int]:
    query = db.execute(select(Registration.status, func.count(Registration.id)).where(Registration.event_id == event_id).group_by(Registration.status)).all()
    values = dict(query)
    return values.get("confirmed", 0), values.get("waitlist", 0)


def lock_event(db: Session, event_id: int) -> Event:
    # BEGIN IMMEDIATE serializes public sign-ups on SQLite; SELECT FOR UPDATE on PostgreSQL.
    if db.bind.dialect.name == "sqlite":
        db.connection().exec_driver_sql("BEGIN IMMEDIATE")
    result = db.execute(select(Event).where(Event.id == event_id).with_for_update()).scalar_one_or_none()
    if not result:
        raise ValueError("Evento não encontrado")
    return result


def register(db: Session, event_id: int, name: str, phone: str, email: str | None,
             consent: bool, public_name: bool) -> tuple[Registration, str]:
    if not consent:
        raise ValueError("É preciso aceitar o uso dos dados para organizar a inscrição.")
    name = " ".join(name.strip().split())
    if len(name) < 3 or len(name) > 140:
        raise ValueError("Informe o nome completo (3 a 140 caracteres).")
    phone = clean_phone(phone)
    event = lock_event(db, event_id)
    if not event.is_published or event.is_closed:
        raise ValueError("Inscrições encerradas.")
    previous = db.scalar(select(Registration).where(Registration.event_id == event_id, Registration.phone == phone))
    if previous and previous.status != "cancelled":
        raise ValueError("Esse WhatsApp já está cadastrado neste evento. Fale com o organizador para atualizar.")
    confirmed, _ = occupancy(db, event_id)
    token = secrets.token_urlsafe(32)
    values = dict(event_id=event_id, full_name=name, phone=phone, email=(email or "").strip() or None,
                  status="confirmed" if confirmed < event.capacity else "waitlist", consent_at=utc_now(),
                  show_name_publicly=public_name, cancellation_token_hash=hash_token(token),
                  payment_status="pending", attended=False)
    if previous:  # Re-registration invalidates the old cancellation link.
        for key, value in values.items():
            setattr(previous, key, value)
        registration = previous
    else:
        registration = Registration(**values)
        db.add(registration)
    db.commit()
    db.refresh(registration)
    return registration, token


def promote_waitlist(db: Session, event_id: int):
    event = db.get(Event, event_id)
    if not event or event.is_closed:
        return
    confirmed, _ = occupancy(db, event_id)
    if confirmed >= event.capacity:
        return
    slots = event.capacity - confirmed
    candidates = db.scalars(select(Registration).where(
        Registration.event_id == event_id, Registration.status == "waitlist"
    ).order_by(Registration.created_at, Registration.id).limit(slots)).all()
    for person in candidates:
        person.status = "confirmed"


def cancel_registration(db: Session, registration: Registration):
    event_id = registration.event_id
    if db.bind.dialect.name == "sqlite":
        db.connection().exec_driver_sql("BEGIN IMMEDIATE")
    else:
        db.execute(select(Event).where(Event.id == event_id).with_for_update()).scalar_one()
    # A previously loaded registration can be stale: reload under lock.
    db.refresh(registration)
    if registration.status == "cancelled":
        return
    was_confirmed = registration.status == "confirmed"
    registration.status = "cancelled"
    db.flush()
    if was_confirmed:
        promote_waitlist(db, event_id)
    db.commit()


def whatsapp_message(event: Event, registrations: list[Registration]) -> str:
    date = event.event_date.strftime("%d/%m/%Y")
    start, end = event.starts_at.strftime("%Hh"), event.ends_at.strftime("%Hh")
    courts = f"{event.court_count} quadra" + ("s" if event.court_count != 1 else "")
    lines = [f"🏐 *{event.title.upper()}* 🏐", "", f"📅 *Data:* {date}",
             f"⏰ *Horário:* {start} às {end}", f"🏐 *{courts.capitalize()}*", "",
             f"📍 *Local:* {event.location_name}", event.address, "",
             f"💰 *Valor:* {money(event.price_cents)}"]
    if event.pix_key:
        lines += [f"🔑 *Chave Pix:* {event.pix_key}"]
    confirmed = [r for r in registrations if r.status == "confirmed"]
    waitlist = [r for r in registrations if r.status == "waitlist"]
    lines += ["", "*LISTA DE PARTICIPANTES*", ""]
    lines += [f"{i}. {r.full_name}" for i, r in enumerate(confirmed, 1)]
    if waitlist:
        lines += ["", "*LISTA DE ESPERA*", ""]
        lines += [f"{i}. {r.full_name}" for i, r in enumerate(waitlist, 1)]
    return "\n".join(lines)
