"""Password hashing and signed-cookie CSRF protection."""
import hashlib
import hmac
import secrets
from fastapi import HTTPException, Request


def password_hash(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 380_000)
    return f"pbkdf2_sha256$380000${salt.hex()}${digest.hex()}"


def check_password(password: str, encoded: str) -> bool:
    try:
        algorithm, n, salt, digest = encoded.split("$")
        if algorithm != "pbkdf2_sha256":
            return False
        computed = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), int(n))
        return hmac.compare_digest(computed, bytes.fromhex(digest))
    except (ValueError, TypeError):
        return False


def csrf_token(request: Request) -> str:
    if not request.session.get("csrf"):
        request.session["csrf"] = secrets.token_urlsafe(32)
    return request.session["csrf"]


def verify_csrf(request: Request, provided: str):
    actual = request.session.get("csrf", "")
    if not actual or not hmac.compare_digest(actual, provided or ""):
        raise HTTPException(403, "Sessão expirada ou formulário inválido. Atualize a página.")


def hash_token(raw: str) -> str:
    return hashlib.sha256(raw.encode()).hexdigest()
