"""Idempotent initialization of a NEW deployment; secrets come from environment."""
import os
from sqlalchemy import select
from .cli import initialize_db, seed
from .database import SessionLocal
from .models import Admin


def main():
    initialize_db()
    email = os.environ.get("ADMIN_EMAIL", "").strip().lower()
    encoded = os.environ.get("ADMIN_PASSWORD_HASH", "")
    if not email or not encoded.startswith("pbkdf2_sha256$"):
        raise RuntimeError("Configure ADMIN_EMAIL e ADMIN_PASSWORD_HASH no ambiente privado.")
    with SessionLocal() as db:
        if not db.scalar(select(Admin).where(Admin.email == email)):
            db.add(Admin(email=email, password_hash=encoded))
            db.commit()
    seed()


if __name__ == "__main__":
    main()
