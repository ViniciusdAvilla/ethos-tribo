"""Behavioral checks for the archived home + real member-only feature visibility."""
import re
from bs4 import BeautifulSoup
from fastapi.testclient import TestClient
from app.main import app
from app.cli import seed


def csrf(html: str) -> str:
    tag = BeautifulSoup(html, "html.parser").select_one('input[name="csrf"]')
    assert tag is not None
    return tag['value']


def test_orig_site_home_section_and_original_assets():
    seed()
    with TestClient(app) as client:
        page = client.get('/')
        assert page.status_code == 200
        soup = BeautifulSoup(page.text, 'html.parser')
        headings = [el.get_text(' ', strip=True) for el in soup.select('main h2')]
        assert 'Próximos encontros .' in headings
        assert headings.index('Próximos encontros .') < headings.index('Uma comunidade que se encontra fora da tela')
        assert soup.find(id='proximos-encontros')
        assert soup.select_one('main img[alt*="Grupo caminhando"]')
        assert '/conta/entrar' in [a.get('href') for a in soup.select('header a')]
        assert 'PRESENÇA<br/>EM JOGO' not in str(soup.find(id='proximos-encontros'))
        assert 'Vôlei Ethos' in soup.find(id='proximos-encontros').get_text()
        assert "style-src 'self' 'unsafe-inline'" in page.headers['content-security-policy']
        assert client.get('/integration/ethos-upcoming.css').status_code == 200
        assert client.get('/_next/static/immutable/chunks/2tahoo7rfwfnb.css').status_code == 200
        assert client.get('/_next/hero-home60f7.jpg').status_code == 200
        assert client.get('/sobre.html').status_code == 200
        assert client.get('/api/sessao').json() == {'autenticado': False}
        assert 'PRESENÇA' not in BeautifulSoup(client.get('/?logged_in=true').text, 'html.parser').find(id='proximos-encontros').get_text()
        event = client.get('/evento/volei-ethos-4-edicao')
        assert event.status_code == 200
        assert 'event-feature' not in event.text


def test_real_member_session_gates_presenca_and_survives_navigation():
    with TestClient(app) as client:
        login = client.get('/conta/entrar')
        assert 'Bem-vindo de volta' in login.text
        bad = client.post('/conta/cadastrar', data={
            'csrf': csrf(client.get('/conta/cadastrar').text),
            'full_name': 'Marina Exemplo', 'email': 'marina@example.com',
            'password': 'curta', 'consent': 'yes',
        })
        assert bad.status_code == 400
        signup_page = client.get('/conta/cadastrar')
        made = client.post('/conta/cadastrar', data={
            'csrf': csrf(signup_page.text),
            'full_name': 'Marina Exemplo', 'email': 'marina@example.com',
            'password': 'SenhaSeguraLonga2026!', 'consent': 'yes',
        }, follow_redirects=False)
        assert made.status_code == 303 and made.headers['location'] == '/conta'
        assert client.get('/api/sessao').json() == {'autenticado': True}
        home = client.get('/')
        assert 'PRESENÇA' in BeautifulSoup(home.text, 'html.parser').find(id='proximos-encontros').get_text()
        assert 'Minha conta' in home.text
        assert 'event-feature' in client.get('/evento/volei-ethos-4-edicao').text
        assert 'Você está conectado' in client.get('/conta').text
        logout = client.post('/conta/sair', data={'csrf': csrf(client.get('/conta').text)}, follow_redirects=False)
        assert logout.status_code == 303
        assert client.get('/api/sessao').json() == {'autenticado': False}
        assert 'PRESENÇA' not in BeautifulSoup(client.get('/').text, 'html.parser').find(id='proximos-encontros').get_text()
        noauth = client.get('/conta', follow_redirects=False)
        assert noauth.status_code == 303 and noauth.headers['location'] == '/conta/entrar'
        sign_back = client.post('/conta/entrar', data={
            'csrf': csrf(client.get('/conta/entrar').text),
            'email':'marina@example.com', 'password':'SenhaSeguraLonga2026!',
        }, follow_redirects=False)
        assert sign_back.status_code == 303
        assert client.get('/api/sessao').json() == {'autenticado': True}
