"""Integration tests for public signup, waiting list, payments and organizer tools."""
import os
import re
import tempfile
from pathlib import Path

# Select a disposable database before importing application-level singleton engine.
_tempdir = tempfile.TemporaryDirectory()
os.environ["APP_ENV"] = "development"
os.environ["SECRET_KEY"] = "test-session-secret-key-only-for-tests-1234567890"
os.environ["DATABASE_URL"] = os.environ.get("ETHOS_TEST_DATABASE_URL", f"sqlite:///{Path(_tempdir.name) / 'test.db'}")
os.environ["BASE_URL"] = "http://testserver"
os.environ["SECURE_COOKIES"] = "false"

from fastapi.testclient import TestClient
from bs4 import BeautifulSoup
from sqlalchemy import select
from app.main import app
from app.cli import seed as original_seed

def seed():
    original_seed()
    with SessionLocal() as db:
        event = db.scalar(select(Event).where(Event.slug == "volei-ethos-4-edicao"))
        if not db.scalar(select(Registration).where(Registration.event_id == event.id)):
            db.add_all([Registration(event_id=event.id, full_name=f"Participante de teste {i}", show_name_publicly=False) for i in range(29)])
            db.commit()

from app.database import SessionLocal
from app.models import Admin, Event, Registration
from app.security import password_hash


def token(response):
    html = BeautifulSoup(response.text, "html.parser")
    item = html.select_one('input[name="csrf"]')
    assert item is not None
    return item["value"]


def register_user(client, name, number):
    page = client.get("/evento/volei-ethos-4-edicao")
    assert page.status_code == 200
    response = client.post("/evento/volei-ethos-4-edicao/inscrever", data={
        "csrf": token(page), "full_name": name, "phone": number,
        "consent": "yes", "show_name": "",
    }, follow_redirects=False)
    return response


def test_full_flow():
    seed()
    seed()  # idempotent
    with SessionLocal() as db:
        event = db.scalar(select(Event).where(Event.slug == "volei-ethos-4-edicao"))
        assert event.capacity == 32
        assert len(db.scalars(select(Registration).where(Registration.event_id == event.id)).all()) == 29
        db.add(Admin(email="admin@example.com", password_hash=password_hash("StrongTestPassword123!")))
        db.commit()
    with TestClient(app) as client:
        assert client.get("/health").json() == {"status": "ok"}
        assert client.get("/").status_code == 200
        data = client.get("/api/eventos").json()
        assert data[0]["inscritos"] == 29
        page = client.get("/evento/volei-ethos-4-edicao")
        assert "Participante de teste 0" not in page.text  # imported names are not public without consent
        assert "Win Juvevê" in page.text
        assert client.post("/evento/volei-ethos-4-edicao/inscrever", data={
            "full_name": "Pessoa Sem Consentimento", "phone": "41999995555"
        }).status_code == 403

        a = register_user(client, "Pessoa Nova Um", "41999990001")
        b = register_user(client, "Pessoa Nova Dois", "41999990002")
        c = register_user(client, "Pessoa Nova Tres", "41999990003")
        waiting = register_user(client, "Pessoa Em Espera", "41999990004")
        for response in [a, b, c, waiting]:
            assert response.status_code == 303
            assert response.headers["location"].startswith("/inscricao/")
        wait_url = waiting.headers["location"]
        wait_page = client.get(wait_url)
        assert "lista de espera" in wait_page.text.lower()
        assert client.get("/api/eventos").json()[0]["inscritos"] == 32
        assert client.get("/api/eventos").json()[0]["lista_espera"] == 1

        duplicate = register_user(client, "Duplicado", "41999990001")
        assert duplicate.status_code == 400
        first_url = a.headers["location"]
        first_page = client.get(first_url)
        assert "Você está na lista" in first_page.text
        cancel = client.post(first_url + "/cancelar", data={"csrf": token(first_page)}, follow_redirects=False)
        assert cancel.status_code == 303
        assert client.get(wait_url).text.count("Você está na lista!") == 1
        assert client.get("/api/eventos").json()[0]["lista_espera"] == 0

        login = client.get("/admin/entrar")
        bad = client.post("/admin/entrar", data={"csrf": token(login), "email": "admin@example.com", "password": "wrong"})
        assert bad.status_code == 401
        logged_in = client.post("/admin/entrar", data={"csrf": token(login),
                             "email": "admin@example.com", "password": "StrongTestPassword123!"},
                                follow_redirects=False)
        assert logged_in.status_code == 303
        dashboard = client.get("/admin")
        assert dashboard.status_code == 200
        assert "Seus encontros" in dashboard.text
        event_admin = client.get("/admin/eventos/1")
        assert event_admin.status_code == 200
        with SessionLocal() as db:
            registration = db.scalar(select(Registration).where(Registration.full_name == "Pessoa Nova Dois"))
            reg_id = registration.id
        update = client.post(f"/admin/inscricoes/{reg_id}/atualizar", data={
            "csrf": token(event_admin), "payment_status": "paid", "attended": "yes"}, follow_redirects=False)
        assert update.status_code == 303
        with SessionLocal() as db:
            r = db.get(Registration, reg_id)
            assert r.payment_status == "paid" and r.attended
        message = client.get("/admin/eventos/1/mensagem")
        assert message.status_code == 200
        assert "Pessoa Nova Dois" in message.text
        assert "Pessoa Nova Um" not in message.text
        csv_file = client.get("/admin/eventos/1/exportar.csv")
        assert csv_file.status_code == 200 and "Pessoa Nova Dois" in csv_file.text
        assert "attachment" in csv_file.headers["content-disposition"]
        logout = client.post("/admin/sair", data={"csrf": token(client.get("/admin"))}, follow_redirects=False)
        assert logout.status_code == 303
        assert client.get("/admin", follow_redirects=False).status_code == 303
        # A canceled participant may use the same WhatsApp again; the old link is invalidated.
        return_again = register_user(client, "Pessoa Nova Um", "41999990001")
        assert return_again.status_code == 303
        assert return_again.headers["location"] != first_url
        assert client.get(first_url).status_code == 404
        assert "lista de espera" in client.get(return_again.headers["location"]).text.lower()


def test_invalid_phone_slug_and_admin_csrf():
    with TestClient(app) as client:
        assert client.get("/evento/nao-existe").status_code == 404
        assert client.get("/privacidade").status_code == 200
        assert client.post("/admin/entrar", data={"email": "test@example.com", "password": "secret"}).status_code == 403


def test_admin_event_creation_edit_and_data_anonymization():
    with TestClient(app) as client:
        login = client.get("/admin/entrar")
        client.post("/admin/entrar", data={"csrf": token(login),
                   "email": "admin@example.com", "password": "StrongTestPassword123!"})
        create_page = client.get("/admin/eventos/novo")
        new_event = client.post("/admin/eventos/novo", data={
            "csrf": token(create_page), "title": "Trilha Ethos", "description": "Caminhada pela manhã",
            "event_date": "2026-10-09", "starts_at": "08:00", "ends_at": "11:00",
            "location_name": "Parque", "address": "Curitiba", "court_count": "1",
            "capacity": "4", "price": "15,90", "pix_key": "41 99999-9999", "is_published": "yes",
        }, follow_redirects=False)
        assert new_event.status_code == 303
        new_admin_url = new_event.headers["location"]
        detail = client.get(new_admin_url)
        assert "Trilha Ethos" in detail.text
        with SessionLocal() as db:
            other = db.scalar(select(Event).where(Event.slug == "trilha-ethos"))
            assert other and other.price_cents == 1590
            event_id = other.id
        new_page = client.get("/evento/trilha-ethos")
        assert new_page.status_code == 200
        manual = client.post(f"/admin/eventos/{event_id}/inscricoes/manual", data={
            "csrf": token(detail), "full_name": "Maria Exemplo"}, follow_redirects=False)
        assert manual.status_code == 303
        with SessionLocal() as db:
            person = db.scalar(select(Registration).where(Registration.event_id == event_id))
            person_id = person.id
        edit = client.get(f"/admin/inscricoes/{person_id}/editar")
        update = client.post(f"/admin/inscricoes/{person_id}/editar", data={
            "csrf": token(edit), "full_name": "Maria Exemplo", "phone": "41998887766",
            "email": "maria@example.com"}, follow_redirects=False)
        assert update.status_code == 303
        with SessionLocal() as db:
            person = db.get(Registration, person_id)
            assert person.phone == "5541998887766" and person.email == "maria@example.com"
        edit_again = client.get(f"/admin/inscricoes/{person_id}/editar")
        erase = client.post(f"/admin/inscricoes/{person_id}/anonimizar",
                            data={"csrf": token(edit_again)}, follow_redirects=False)
        assert erase.status_code == 303
        with SessionLocal() as db:
            person = db.get(Registration, person_id)
            assert person.status == "cancelled" and person.phone is None
            assert person.full_name.startswith("Inscrição anonimizada")
